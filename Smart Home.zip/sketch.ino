//C ++ Code 
#include <Servo.h>
#include <LiquidCrystal.h>
#include <IRremote.h>
//Creating Vraiables
String msg="Password: ";
String Password="Paul";
String msg2="ROOM LED: ";
int rs=7;
int en=8;
int p1=9;
int p2=10;
int p3=11;
int p4=12;
int IRPin=6;
int echo=17;
int trig=15;
int Traveltime;
int ButtonRead;
String pass;
String led;
String Mode;
int vert;
int horz;
int Servoh;
int Servov;

IRrecv IR(IRPin);
decode_results cmd;
String mycom;
LiquidCrystal lcd(rs,en,p1,p2,p3,p4);
Servo Yservo;
Servo Xservo;

void setup(){
  pinMode(A6,INPUT);
  pinMode(1, OUTPUT);
  pinMode(2,INPUT);
  //Controlling the remote
  
  IR. enableIRIn();

  //Controlling the lcd display
  lcd.begin(16,2);
  
  //Opening the Serial Monitor 
  Serial.begin(9600);
  
  //Controlling the Servo

  Yservo.attach(4);
  Xservo.attach(14);

  //Controlling the Ultrasonic Sensor
  pinMode(echo,INPUT);
  pinMode(trig, OUTPUT);

  //Controlling the RGB Leds
  pinMode(21,OUTPUT);
  pinMode(20,OUTPUT);
  pinMode(19,OUTPUT);

  //Controlling the Signal LED
  pinMode(5,OUTPUT);
  // Mkaing sure the switches are good and intact
  digitalWrite(3,HIGH);
  digitalWrite(2,HIGH);
}

void loop(){
  //setting up the Ultrasonic sensor to make the user come closer
  digitalWrite(15,LOW);
  delayMicroseconds(10);
  digitalWrite(15,HIGH);
  delayMicroseconds(10);
  digitalWrite(15,LOW);

  Traveltime=pulseIn(17,HIGH);
  
  delay(25);
   //Opening the LCD
   lcd.setCursor(0,0);

  if(Traveltime<=4350){
    lcd.print("Hello User");
    delay(100);
    lcd.clear();
    lcd.setCursor(0,0);
    lcd.print("Youre in range of sensor");
    delay(1000);
    lcd.setCursor(0,1);
    lcd.print("Please click the push button");
    //Reading the pushbutton

    ButtonRead=digitalRead(3);
    if(ButtonRead==0){
      lcd.clear();
      lcd.setCursor(0,0);
      lcd.print(msg);
      Serial.println(msg);
      while(Serial.available()==0){

      }
      pass=Serial.readString();
      if (pass=="Paul"){
        lcd.clear();
        lcd.setCursor(0,0);
        lcd.print("Password is correct");
        
        lcd.setCursor(0,1);
        lcd.print("Welcome User");
        Yservo.write(180);
        delay(1000);
        Yservo.write(90);
        
        delay(200);
        //Make the purple LED glow
        digitalWrite(5,HIGH);
        lcd.clear();
        lcd.setCursor(0,0);
        lcd.print("Enter LED: ");

        Serial.println(msg2);
        while(Serial.available()==0){

        }
        led=Serial.readString();
        //RED LED
        if (led=="Red" || led=="red"){
          digitalWrite(19,HIGH);
        }
        //BLUE LED
        if(led=="Blue" || led=="blue"){

          digitalWrite(21,HIGH);
        }
        //Green LED
        
        if(led=="Green" || led=="green"){

          digitalWrite(20,HIGH);

        }

        lcd.clear();
        lcd.setCursor(0,0);
        lcd.print("Servo CCTV ON? ");
        lcd.setCursor(0,1);

        Serial.println("Servo CCTV Mode (Joystick/ IRremote): ");
        while(Serial.available()==0){

        }
        Mode=Serial.readString();
        lcd.clear();
        lcd.setCursor(0,0);
        lcd.print("Yellow for Vert");
        lcd.setCursor(0,1);
        lcd.print("Blue for Horz");
        if(Mode="Joystick"){

          vert=analogRead(A4);
          horz=analogRead(A5);
          Servov=((180./1023.)*vert);
          Servoh=((180./1023.)*horz);
          Yservo.write(Servov);
          Xservo.write(Servoh);

        }
        if(Mode="IRremote"){
          while(IR.decode(&cmd)==0){

          }
          IR.resume();
          if(cmd.value == 0xFFA857){
            Yservo.write(180);
            delay(1000);
            Yservo.write(90);

          }

          if(cmd.value == 0xFFE01F){
            Yservo.write(0);
            delay(1000);
            Yservo.write(90);
          }

          if(cmd.value == 0xFF02FD){
            Xservo.write(180);
            delay(1000);
            Xservo.write(90);
          }

          if(cmd.value == 0xFF22DD){
            Xservo.write(0);
            delay(1000);
            Xservo.write(90); 
          }

        }
        else{
          lcd.print("valid mode: ");
          Serial.println("Servo CCTV Mode: ");
          while(Serial.available()==0){

          }
          Mode=Serial.readString();
        }



      }
      else{
        lcd.clear();
        lcd.setCursor(0,0);
        lcd.print("The password is incorrect");

        digitalWrite(1,HIGH);
        lcd.clear();
        lcd.setCursor(0,0);
        lcd.print("Get out");
        lcd.setCursor(0,1);
        lcd.print("before i call the police !!");
        delay(5000);

        if(Traveltime<=4350){
          lcd.clear();
          lcd.setCursor(0,0);
          lcd.print("The CCTV called 911");


        }
      }
    }
    
    
    
  }

  else{
    lcd.print("Come closer to sensor");
  }
  
}


